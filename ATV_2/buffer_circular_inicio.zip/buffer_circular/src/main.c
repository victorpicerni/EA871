/* Teste de um buffer circular
 *
 * Este programa serve para implementar e testar uma implementacao de buffer
 * circular
 */

#include <stdio.h>

char buffer[5];

void adicionar_buffer(char c) {
/* Preencha com seu codigo! */

}

void remover_buffer() {
/* Preencha com seu codigo! */

}

void imprimir_buffer() {
/* Preencha com seu codigo! */

}

int main() {


  char c;

  do {
    scanf("%c", &c);
    if (c == '\n') break;

  /* Sugestao: aqui deveria vir o seu codigo */

  } while (1);

  return 0;
}
